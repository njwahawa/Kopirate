<?php
require __DIR__ . '/includes/functions.php';

$pdo = db();

/* ---------- Pencarian & urutan ---------- */
$q    = trim((string) ($_GET['q'] ?? ''));
$sort = (string) ($_GET['sort'] ?? 'rating');

$sortLabels = [
    'rating'    => 'Rating tertinggi',
    'taste'     => 'Rasa kopi terbaik',
    'facility'  => 'Fasilitas terbaik',
    'responden' => 'Responden terbanyak',
    'nama'      => 'Nama A-Z',
];
$avgAll = 'AVG(' . OVERALL_SQL . ')';
$orders = [
    'rating'    => "COUNT(r.id) = 0, $avgAll DESC, COUNT(r.id) DESC",
    'taste'     => 'COUNT(r.id) = 0, AVG(r.rating_taste) DESC, COUNT(r.id) DESC',
    'facility'  => 'COUNT(r.id) = 0, AVG(r.rating_facility) DESC, COUNT(r.id) DESC',
    'responden' => "COUNT(r.id) DESC, $avgAll DESC",
    'nama'      => 's.name ASC',
];
if (!isset($orders[$sort])) {
    $sort = 'rating';
}

$where  = '';
$params = [];
if ($q !== '') {
    $where         = ' WHERE (s.name LIKE :q1 OR s.location LIKE :q2)';
    $params[':q1'] = '%' . $q . '%';
    $params[':q2'] = '%' . $q . '%';
}

$sql = 'SELECT s.*, COUNT(r.id) AS total,
               AVG(' . OVERALL_SQL . ') AS avg_overall,
               AVG(r.rating_taste)      AS avg_taste,
               AVG(r.rating_facility)   AS avg_facility
        FROM coffee_shops s
        LEFT JOIN reviews r ON r.shop_id = s.id'
    . $where . ' GROUP BY s.id ORDER BY ' . $orders[$sort];
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$shops = $stmt->fetchAll();

$topReason  = top_answer_by_shop($pdo, 'reason');
$topPurpose = top_answer_by_shop($pdo, 'purpose');

/* ---------- Data struk di hero ---------- */
$stats = $pdo->query('SELECT (SELECT COUNT(*) FROM coffee_shops) AS shops,
                             (SELECT COUNT(*) FROM reviews)      AS reviews')->fetch();

$ranking = $pdo->query('SELECT s.id, s.name, COUNT(r.id) AS total, AVG(' . OVERALL_SQL . ') AS avg_overall
                        FROM coffee_shops s
                        INNER JOIN reviews r ON r.shop_id = s.id
                        GROUP BY s.id
                        ORDER BY avg_overall DESC, total DESC
                        LIMIT 5')->fetchAll();

$pageTitle = 'Coffee shop ter-worth-it untuk kantong anak kos';
$activeNav = 'home';
include __DIR__ . '/includes/header.php';
?>

<section class="hero">
    <div class="container hero-grid">
        <div>
            <h1>Coffee shop mana yang worth-it buat kantong anak kos?</h1>
            <p class="lead">
                Lihat rating rasa kopi dan fasilitas dari pengunjung coffee shop di Samarinda, lengkap dengan
                kebiasaan nongkrong mereka. Sudah pernah mampir? Isi penilaianmu, cuma dua menit.
            </p>
            <div class="hero-actions">
                <a class="btn" href="rate.php">Beri rating</a>
                <a class="btn btn-ghost" href="statistik.php">Lihat hasil survei</a>
            </div>
        </div>

        <div class="hero-stage">
            <div class="receipt" aria-label="Peringkat coffee shop berdasarkan rating">
                <div class="receipt-title">KOPIRATE SAMARINDA</div>
                <div class="receipt-sub">Struk peringkat</div>
                <hr>
                <?php if (!$ranking): ?>
                    <p class="receipt-empty">Belum ada penilaian.<br>Jadi yang pertama memberi rating!</p>
                <?php else: ?>
                    <?php foreach ($ranking as $i => $t): ?>
                        <a class="receipt-item" href="shop.php?id=<?= (int) $t['id'] ?>">
                            <span><?= $i + 1 ?></span>
                            <span class="receipt-name"><?= e($t['name']) ?></span>
                            <strong><?= e(score($t['avg_overall'])) ?></strong>
                            <span class="receipt-beans"><?= beans($t['avg_overall']) ?> <small><?= (int) $t['total'] ?> responden</small></span>
                        </a>
                    <?php endforeach; ?>
                <?php endif; ?>
                <hr>
                <div class="receipt-total"><span>Coffee shop</span><span><?= (int) $stats['shops'] ?></span></div>
                <div class="receipt-total"><span>Total responden</span><span><?= (int) $stats['reviews'] ?></span></div>
                <hr>
                <p class="receipt-thanks">Terima kasih sudah ngopi!</p>
            </div>
        </div>
    </div>
</section>

<section class="section" id="daftar">
    <div class="container">
        <h2>Coffee shop yang dinilai</h2>

        <form class="filters" method="get" action="index.php#daftar">
            <div class="field">
                <label for="q">Cari coffee shop</label>
                <input type="text" id="q" name="q" value="<?= e($q) ?>" placeholder="Contoh: Tomoro">
            </div>
            <div class="field">
                <label for="sort">Urutkan</label>
                <select id="sort" name="sort">
                    <?php foreach ($sortLabels as $key => $label): ?>
                        <option value="<?= e($key) ?>" <?= $key === $sort ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button class="btn" type="submit">Terapkan</button>
        </form>

        <?php if (!$shops): ?>
            <div class="empty">
                <h3>Tidak ada coffee shop yang cocok</h3>
                <p>Coba kata kunci lain.</p>
                <a class="btn btn-ghost" href="index.php#daftar">Reset pencarian</a>
            </div>
        <?php else: ?>
            <div class="grid">
                <?php foreach ($shops as $s): $n = (int) $s['total']; ?>
                    <article class="card">
                        <div class="card-cover tone-<?= cover_tone((int) $s['id']) ?>">
                            <span class="tag"><?= $n ?> responden</span>
                            <span class="card-initial" aria-hidden="true"><?= e(mb_strtoupper(mb_substr($s['name'], 0, 1))) ?></span>
                        </div>
                        <div class="card-body">
                            <h3><a href="shop.php?id=<?= (int) $s['id'] ?>"><?= e($s['name']) ?></a></h3>
                            <?php if ($s['location']): ?><p class="meta"><?= e($s['location']) ?></p><?php endif; ?>

                            <?php if ($n > 0): ?>
                                <div class="score-line">
                                    <?= beans($s['avg_overall']) ?>
                                    <strong><?= e(score($s['avg_overall'])) ?></strong>
                                    <span class="meta">dari 5</span>
                                </div>

                                <div class="mini-bars">
                                    <div class="mini-row">
                                        <span>Rasa kopi</span>
                                        <div class="bar"><span style="width:<?= round((float) $s['avg_taste'] / 5 * 100) ?>%"></span></div>
                                        <b><?= e(score($s['avg_taste'])) ?></b>
                                    </div>
                                    <div class="mini-row">
                                        <span>Fasilitas</span>
                                        <div class="bar"><span style="width:<?= round((float) $s['avg_facility'] / 5 * 100) ?>%"></span></div>
                                        <b><?= e(score($s['avg_facility'])) ?></b>
                                    </div>
                                </div>

                                <dl class="mini-facts">
                                    <?php if (isset($topReason[$s['id']])): ?>
                                        <div><dt>Alasan terbanyak</dt><dd><?= e($topReason[$s['id']]) ?></dd></div>
                                    <?php endif; ?>
                                    <?php if (isset($topPurpose[$s['id']])): ?>
                                        <div><dt>Tujuan terbanyak</dt><dd><?= e($topPurpose[$s['id']]) ?></dd></div>
                                    <?php endif; ?>
                                </dl>
                            <?php else: ?>
                                <p class="meta">Belum ada yang menilai coffee shop ini.</p>
                            <?php endif; ?>

                            <div class="card-foot">
                                <a class="meta-link" href="shop.php?id=<?= (int) $s['id'] ?>">Lihat detail</a>
                                <a class="btn btn-sm btn-pink card-action" href="rate.php?shop=<?= (int) $s['id'] ?>">Beri rating</a>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<section class="section steps">
    <div class="container">
        <h2>Cara kerjanya</h2>
        <ol class="steps-list">
            <li>
                <h3>Isi profil singkat</h3>
                <p>Nama, usia, seberapa sering kamu nongkrong, dan rata-rata harga minuman yang kamu beli.</p>
            </li>
            <li>
                <h3>Pilih dan nilai</h3>
                <p>Pilih coffee shop yang sering kamu kunjungi, lalu beri nilai rasa kopi dan fasilitasnya dari 1 sampai 5.</p>
            </li>
            <li>
                <h3>Ceritakan kebiasaanmu</h3>
                <p>Jawab tujuh pertanyaan singkat, lalu lihat rangkumannya di halaman hasil survei.</p>
            </li>
        </ol>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
