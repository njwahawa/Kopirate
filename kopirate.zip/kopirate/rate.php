<?php
require __DIR__ . '/includes/functions.php';

$pdo     = db();
$shops   = $pdo->query('SELECT id, name, location FROM coffee_shops ORDER BY id')->fetchAll();
$shopIds = array_map('intval', array_column($shops, 'id'));

$errors = [];
$old = ['reviewer_name' => '', 'shop_id' => (int) ($_GET['shop'] ?? 0)];
foreach (CHOICE_QUESTIONS as $key => $q) {
    $old[$key] = '';
}
foreach (CRITERIA as $key => $meta) {
    $old[$key] = 0;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Kolom jebakan untuk bot: manusia tidak akan mengisinya
    if (!empty($_POST['website'])) {
        header('Location: index.php');
        exit;
    }
    if (!csrf_valid()) {
        $errors[] = 'Sesi formulir sudah kedaluwarsa. Muat ulang halaman lalu coba lagi.';
    }

    $old['reviewer_name'] = trim((string) ($_POST['reviewer_name'] ?? ''));
    $old['shop_id']       = (int) ($_POST['shop_id'] ?? 0);

    $nameLen = mb_strlen($old['reviewer_name']);
    if ($nameLen < 2 || $nameLen > 80) {
        $errors[] = 'Nama harus diisi, 2 sampai 80 karakter.';
    }

    foreach (CHOICE_QUESTIONS as $key => $q) {
        $old[$key] = (string) ($_POST[$key] ?? '');
        if (!in_array($old[$key], $q['options'], true)) {
            $errors[] = 'Pertanyaan belum dijawab: "' . $q['label'] . '"';
        }
    }

    if (!in_array($old['shop_id'], $shopIds, true)) {
        $errors[] = 'Pilih coffe shop yang sering kamu kunjungi.';
    }

    foreach (CRITERIA as $key => $meta) {
        $val = (int) ($_POST[$key] ?? 0);
        if ($val < 1 || $val > 5) {
            $errors[] = 'Beri nilai 1 sampai 5 untuk "' . $meta['label'] . '".';
        }
        $old[$key] = $val;
    }

    if (!$errors) {
        // Nama kolom berasal dari konstanta di functions.php, bukan dari input pengguna
        $cols   = array_merge(['shop_id', 'reviewer_name'], array_keys(CHOICE_QUESTIONS), array_keys(CRITERIA));
        $sql    = 'INSERT INTO reviews (' . implode(', ', $cols) . ') VALUES (:' . implode(', :', $cols) . ')';
        $values = [];
        foreach ($cols as $c) {
            $values[':' . $c] = $old[$c];
        }
        $pdo->prepare($sql)->execute($values);

        header('Location: shop.php?id=' . $old['shop_id'] . '&sent=1');
        exit;
    }
}

/** Satu pertanyaan pilihan ganda (radio berbentuk chip). */
function render_choice(string $key, array $q, string $current): void
{
    $stack = $q['layout'] === 'stack' ? ' chips-stack' : '';
    echo '<fieldset class="field"><legend>' . e($q['label']) . '</legend><div class="chips' . $stack . '">';
    foreach ($q['options'] as $opt) {
        echo '<label class="chip"><input type="radio" name="' . e($key) . '" value="' . e($opt) . '" required'
            . ($current === $opt ? ' checked' : '') . '><span>' . e($opt) . '</span></label>';
    }
    echo '</div></fieldset>';
}

$pageTitle = 'Beri rating coffee shop';
$activeNav = 'rate';
include __DIR__ . '/includes/header.php';
?>

<section class="section">
    <div class="container rate-layout">

        <aside class="rate-intro">
            <h1>Nilai coffee shop langgananmu</h1>
            <p>Jawabanmu membantu anak kos lain menemukan tempat ngopi yang pas di kantong. Tidak perlu login.</p>
            <div class="live-score" aria-live="polite">
                <span class="live-label">Rata-rata nilaimu</span>
                <span class="live-beans" id="live-beans"><?= beans(0, 'beans-lg') ?></span>
                <strong id="live-number">-</strong>
            </div>
        </aside>

        <form class="rate-form" method="post" action="rate.php" data-words="<?= e(json_encode(RATING_WORDS)) ?>">
            <?= csrf_field() ?>
            <div class="hp" aria-hidden="true">
                <label>Website <input type="text" name="website" tabindex="-1" autocomplete="off"></label>
            </div>

            <?php if ($errors): ?>
                <div class="alert alert-err" role="alert">
                    <strong>Formulir belum lengkap:</strong>
                    <ul>
                        <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <!-- ===== Halaman 1: profil ===== -->
            <div class="form-panel">
                <h2>Tentang kamu</h2>

                <div class="field">
                    <label for="reviewer_name">Nama</label>
                    <input type="text" id="reviewer_name" name="reviewer_name" maxlength="80" required
                           value="<?= e($old['reviewer_name']) ?>" placeholder="Jawaban Anda">
                </div>

                <?php foreach (CHOICE_QUESTIONS as $key => $q): ?>
                    <?php if ($q['group'] === 'profile') { render_choice($key, $q, $old[$key]); } ?>
                <?php endforeach; ?>
            </div>

            <!-- ===== Halaman 2: penilaian ===== -->
            <div class="form-panel">
                <h2>Penilaian</h2>

                <div class="scale-legend">
                    <ul>
                        <?php foreach (RATING_WORDS as $n => $word): ?>
                            <li><b><?= $n ?></b> = <?= e($word) ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <p>Jawab sesuai coffe shop yang kalian pilih</p>
                </div>

                <fieldset class="field">
                    <legend>Coffe shop apa yang sering Anda kunjungi</legend>
                    <div class="chips">
                        <?php foreach ($shops as $s): ?>
                            <label class="chip">
                                <input type="radio" name="shop_id" value="<?= (int) $s['id'] ?>" required
                                       <?= (int) $s['id'] === $old['shop_id'] ? 'checked' : '' ?>>
                                <span><?= e($s['name']) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <?php if (!$shops): ?>
                        <p class="hint">Belum ada coffee shop. Tambahkan dulu lewat halaman Admin.</p>
                    <?php endif; ?>
                </fieldset>

                <?php foreach (CRITERIA as $key => $meta): ?>
                    <div class="rate-row" role="radiogroup" aria-labelledby="lbl-<?= e($key) ?>">
                        <div>
                            <div class="rate-label" id="lbl-<?= e($key) ?>"><?= e($meta['label']) ?></div>
                            <div class="rate-hint"><?= e($meta['hint']) ?></div>
                        </div>
                        <div class="rate-control">
                            <div class="bean-input">
                                <?php for ($v = 5; $v >= 1; $v--): ?>
                                    <input type="radio" name="<?= e($key) ?>" id="<?= e($key) ?>-<?= $v ?>" value="<?= $v ?>"
                                           required <?= $old[$key] === $v ? 'checked' : '' ?>>
                                    <label for="<?= e($key) ?>-<?= $v ?>" title="<?= $v ?> = <?= e(RATING_WORDS[$v]) ?>">
                                        <span class="sr-only"><?= $v ?> = <?= e(RATING_WORDS[$v]) ?></span><?= bean_svg() ?>
                                    </label>
                                <?php endfor; ?>
                            </div>
                            <output class="rate-word">Belum dinilai</output>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- ===== Halaman 2: kebiasaan ===== -->
            <div class="form-panel">
                <h2>Kebiasaan ngopi</h2>
                <?php foreach (CHOICE_QUESTIONS as $key => $q): ?>
                    <?php if ($q['group'] === 'habit') { render_choice($key, $q, $old[$key]); } ?>
                <?php endforeach; ?>
            </div>

            <button class="btn btn-lg" type="submit">Kirim</button>
        </form>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
