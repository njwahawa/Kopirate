<?php
// Dipanggil di awal setiap halaman admin (kecuali login.php)
require_once __DIR__ . '/../includes/functions.php';

if (empty($_SESSION['is_admin'])) {
    header('Location: login.php');
    exit;
}
