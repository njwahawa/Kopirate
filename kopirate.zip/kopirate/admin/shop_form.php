<?php
require_once __DIR__ . '/_auth.php';

$pdo = db();
$id  = (int) ($_GET['id'] ?? 0);

$shop = ['name' => '', 'location' => '', 'description' => ''];

if ($id > 0) {
    $stmt = $pdo->prepare('SELECT * FROM coffee_shops WHERE id = :id');
    $stmt->execute([':id' => $id]);
    $found = $stmt->fetch();
    if (!$found) {
        http_response_code(404);
        exit('Coffee shop tidak ditemukan.');
    }
    $shop = $found;
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        $errors[] = 'Sesi kedaluwarsa. Muat ulang halaman lalu coba lagi.';
    }

    $shop['name']        = trim((string) ($_POST['name'] ?? ''));
    $shop['location']    = trim((string) ($_POST['location'] ?? ''));
    $shop['description'] = trim((string) ($_POST['description'] ?? ''));

    if ($shop['name'] === '' || mb_strlen($shop['name']) > 120) {
        $errors[] = 'Nama coffee shop wajib diisi (maksimal 120 karakter).';
    }
    if (mb_strlen($shop['location']) > 255) {
        $errors[] = 'Lokasi maksimal 255 karakter.';
    }

    if (!$errors) {
        $data = [
            ':name'  => $shop['name'],
            ':loc'   => $shop['location'] !== '' ? $shop['location'] : null,
            ':descr' => $shop['description'] !== '' ? $shop['description'] : null,
        ];
        if ($id > 0) {
            $data[':id'] = $id;
            $pdo->prepare('UPDATE coffee_shops SET name = :name, location = :loc, description = :descr WHERE id = :id')->execute($data);
        } else {
            $pdo->prepare('INSERT INTO coffee_shops (name, location, description) VALUES (:name, :loc, :descr)')->execute($data);
        }
        header('Location: index.php?msg=shop_saved');
        exit;
    }
}

$base      = '../';
$isAdmin   = true;
$activeNav = 'admin';
$pageTitle = $id > 0 ? 'Ubah coffee shop' : 'Tambah coffee shop';
include __DIR__ . '/../includes/header.php';
?>

<section class="section admin-wrap">
    <div class="container narrow">
        <h1><?= e($pageTitle) ?></h1>

        <?php if ($errors): ?>
            <div class="alert alert-err" role="alert">
                <ul><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
            </div>
        <?php endif; ?>

        <form class="form-panel" method="post" action="shop_form.php<?= $id > 0 ? '?id=' . $id : '' ?>">
            <?= csrf_field() ?>
            <div class="field">
                <label for="name">Nama coffee shop</label>
                <input type="text" id="name" name="name" maxlength="120" required value="<?= e($shop['name']) ?>">
            </div>
            <div class="field">
                <label for="location">Lokasi / cabang di Samarinda (opsional)</label>
                <input type="text" id="location" name="location" maxlength="255" placeholder="Contoh: Jl. Pahlawan, Samarinda Ulu" value="<?= e($shop['location']) ?>">
            </div>
            <div class="field">
                <label for="description">Deskripsi singkat (opsional)</label>
                <textarea id="description" name="description" rows="4"><?= e($shop['description']) ?></textarea>
            </div>
            <div class="form-actions">
                <button class="btn" type="submit">Simpan</button>
                <a class="btn btn-ghost" href="index.php">Batal</a>
            </div>
        </form>
    </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
