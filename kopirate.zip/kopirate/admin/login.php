<?php
require_once __DIR__ . '/../includes/functions.php';

if (!empty($_SESSION['is_admin'])) {
    header('Location: index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = (string) ($_POST['username'] ?? '');
    $pass = (string) ($_POST['password'] ?? '');

    if (!csrf_valid()) {
        $error = 'Sesi kedaluwarsa. Muat ulang halaman lalu coba lagi.';
    } elseif (hash_equals(ADMIN_USER, $user) && hash_equals(ADMIN_PASS, $pass)) {
        session_regenerate_id(true);
        $_SESSION['is_admin'] = true;
        header('Location: index.php');
        exit;
    } else {
        $error = 'Username atau password salah.';
    }
}

$base      = '../';
$pageTitle = 'Masuk admin';
$activeNav = 'admin';
include __DIR__ . '/../includes/header.php';
?>

<section class="section">
    <div class="container">
        <div class="login-box form-panel">
            <h1>Masuk admin</h1>
            <p class="hint">Halaman ini untuk mengelola data coffee shop dan jawaban responden.</p>

            <?php if ($error): ?><div class="alert alert-err" role="alert"><?= e($error) ?></div><?php endif; ?>

            <form method="post" action="login.php">
                <?= csrf_field() ?>
                <div class="field">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required autocomplete="username">
                </div>
                <div class="field">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required autocomplete="current-password">
                </div>
                <button class="btn" type="submit">Masuk</button>
            </form>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
