<?php
// Unduh semua jawaban responden sebagai CSV (bisa dibuka di Excel)
require_once __DIR__ . '/_auth.php';

$pdo = db();

$headers = ['ID', 'Tanggal', 'Coffe shop', 'Nama'];
foreach (CHOICE_QUESTIONS as $q) {
    if ($q['group'] === 'profile') { $headers[] = $q['short']; }
}
foreach (CRITERIA as $meta) {
    $headers[] = $meta['label'] . ' (1-5)';
}
foreach (CHOICE_QUESTIONS as $q) {
    if ($q['group'] === 'habit') { $headers[] = $q['short']; }
}

$rows = $pdo->query('SELECT r.*, s.name AS shop_name FROM reviews r
                     JOIN coffee_shops s ON s.id = r.shop_id
                     ORDER BY r.id')->fetchAll();

// Cegah "CSV injection": sel yang diawali = + - @ dianggap rumus oleh Excel
function csv_safe(string $v): string
{
    return preg_match('/^[=+\-@\t\r]/', $v) ? "'" . $v : $v;
}

header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="responden-kopirate-' . date('Ymd-His') . '.csv"');

$out = fopen('php://output', 'w');
fwrite($out, "\xEF\xBB\xBF"); // BOM agar Excel membaca UTF-8
fputcsv($out, $headers, ',', '"', '\\');

foreach ($rows as $r) {
    $line = [$r['id'], $r['created_at'], csv_safe($r['shop_name']), csv_safe($r['reviewer_name'])];
    foreach (CHOICE_QUESTIONS as $key => $q) {
        if ($q['group'] === 'profile') { $line[] = $r[$key]; }
    }
    foreach (array_keys(CRITERIA) as $key) {
        $line[] = $r[$key];
    }
    foreach (CHOICE_QUESTIONS as $key => $q) {
        if ($q['group'] === 'habit') { $line[] = $r[$key]; }
    }
    fputcsv($out, $line, ',', '"', '\\');
}
fclose($out);
exit;
