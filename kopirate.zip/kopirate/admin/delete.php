<?php
require_once __DIR__ . '/_auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_valid()) {
    http_response_code(400);
    exit('Permintaan tidak valid.');
}

$pdo  = db();
$type = (string) ($_POST['type'] ?? '');
$id   = (int) ($_POST['id'] ?? 0);

if ($type === 'shop') {
    $pdo->prepare('DELETE FROM coffee_shops WHERE id = :id')->execute([':id' => $id]); // jawaban responden ikut terhapus (CASCADE)
    header('Location: index.php?msg=shop_deleted');
} elseif ($type === 'review') {
    $pdo->prepare('DELETE FROM reviews WHERE id = :id')->execute([':id' => $id]);
    header('Location: index.php?msg=review_deleted#responden');
} else {
    http_response_code(400);
    exit('Jenis data tidak dikenal.');
}
exit;
