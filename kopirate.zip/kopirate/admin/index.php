<?php
require_once __DIR__ . '/_auth.php';

$pdo = db();

$stats = $pdo->query('SELECT (SELECT COUNT(*) FROM coffee_shops) AS shops,
                             (SELECT COUNT(*) FROM reviews) AS reviews,
                             (SELECT AVG(' . OVERALL_SQL . ') FROM reviews r) AS avg_all')->fetch();

$shops = $pdo->query('SELECT s.*, COUNT(r.id) AS total,
                             AVG(r.rating_taste) AS avg_taste, AVG(r.rating_facility) AS avg_facility,
                             AVG(' . OVERALL_SQL . ') AS avg_overall
                      FROM coffee_shops s LEFT JOIN reviews r ON r.shop_id = s.id
                      GROUP BY s.id ORDER BY s.id')->fetchAll();

$reviews = $pdo->query('SELECT r.id, r.reviewer_name, r.age_group, r.purpose, r.rating_taste, r.rating_facility,
                               r.created_at, s.name AS shop_name
                        FROM reviews r JOIN coffee_shops s ON s.id = r.shop_id
                        ORDER BY r.created_at DESC, r.id DESC LIMIT 50')->fetchAll();

$messages = [
    'shop_saved'     => 'Data coffee shop tersimpan.',
    'shop_deleted'   => 'Coffee shop dan semua jawabannya sudah dihapus.',
    'review_deleted' => 'Jawaban responden sudah dihapus.',
];
$msg = $messages[$_GET['msg'] ?? ''] ?? '';

$base      = '../';
$isAdmin   = true;
$activeNav = 'admin';
$pageTitle = 'Dasbor admin';
include __DIR__ . '/../includes/header.php';
?>

<section class="section admin-wrap">
    <div class="container">
        <h1>Dasbor admin</h1>

        <?php if ($msg): ?><div class="alert alert-ok" role="status"><?= e($msg) ?></div><?php endif; ?>

        <div class="stat-row">
            <div class="stat"><b><?= (int) $stats['shops'] ?></b>Coffee shop</div>
            <div class="stat"><b><?= (int) $stats['reviews'] ?></b>Responden</div>
            <div class="stat"><b><?= e(score($stats['avg_all'])) ?></b>Rata-rata rating</div>
        </div>

        <div class="admin-head">
            <h2>Coffee shop</h2>
            <a class="btn btn-sm" href="shop_form.php">Tambah coffee shop</a>
        </div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Nama</th><th>Lokasi</th><th>Responden</th><th>Rasa</th><th>Fasilitas</th><th>Rata-rata</th><th>Aksi</th></tr></thead>
                <tbody>
                <?php foreach ($shops as $s): ?>
                    <tr>
                        <td><a href="../shop.php?id=<?= (int) $s['id'] ?>"><strong><?= e($s['name']) ?></strong></a></td>
                        <td><?= $s['location'] ? e($s['location']) : '-' ?></td>
                        <td><?= (int) $s['total'] ?></td>
                        <td><?= e(score($s['avg_taste'])) ?></td>
                        <td><?= e(score($s['avg_facility'])) ?></td>
                        <td><?= e(score($s['avg_overall'])) ?></td>
                        <td class="actions">
                            <a class="btn btn-sm btn-ghost" href="shop_form.php?id=<?= (int) $s['id'] ?>">Ubah</a>
                            <form method="post" action="delete.php" onsubmit="return confirm('Hapus coffee shop ini beserta semua jawaban respondennya?');">
                                <?= csrf_field() ?>
                                <input type="hidden" name="type" value="shop">
                                <input type="hidden" name="id" value="<?= (int) $s['id'] ?>">
                                <button class="btn btn-sm btn-ghost" type="submit">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$shops): ?><tr><td colspan="7">Belum ada coffee shop.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="admin-head" id="responden">
            <h2>Jawaban terbaru</h2>
            <a class="btn btn-sm btn-ghost" href="export.php">Unduh semua (CSV)</a>
        </div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Tanggal</th><th>Coffee shop</th><th>Responden</th><th>Tujuan</th><th>Rasa</th><th>Fasilitas</th><th>Aksi</th></tr></thead>
                <tbody>
                <?php foreach ($reviews as $r): ?>
                    <tr>
                        <td><?= e(tanggal($r['created_at'])) ?></td>
                        <td><?= e($r['shop_name']) ?></td>
                        <td><?= e($r['reviewer_name']) ?><br><small class="meta"><?= e($r['age_group']) ?></small></td>
                        <td><?= e($r['purpose']) ?></td>
                        <td><?= (int) $r['rating_taste'] ?></td>
                        <td><?= (int) $r['rating_facility'] ?></td>
                        <td class="actions">
                            <form method="post" action="delete.php" onsubmit="return confirm('Hapus jawaban ini?');">
                                <?= csrf_field() ?>
                                <input type="hidden" name="type" value="review">
                                <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                                <button class="btn btn-sm btn-ghost" type="submit">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$reviews): ?><tr><td colspan="7">Belum ada jawaban masuk.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
