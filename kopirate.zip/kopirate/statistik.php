<?php
require __DIR__ . '/includes/functions.php';

$pdo    = db();
$shopId = (int) ($_GET['shop'] ?? 0);

$shops = $pdo->query('SELECT id, name FROM coffee_shops ORDER BY name')->fetchAll();
if (!in_array($shopId, array_map('intval', array_column($shops, 'id')), true)) {
    $shopId = 0; // 0 = semua coffee shop
}
$filter = $shopId > 0 ? $shopId : null;

$totalResp = (int) $pdo->query('SELECT COUNT(*) FROM reviews')->fetchColumn();

if ($filter) {
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM reviews WHERE shop_id = :id');
    $stmt->execute([':id' => $filter]);
    $shownResp = (int) $stmt->fetchColumn();
} else {
    $shownResp = $totalResp;
}

/* ---------- Tabel perbandingan ---------- */
$compare = $pdo->query('SELECT s.id, s.name, COUNT(r.id) AS total,
                               AVG(r.rating_taste) AS avg_taste, AVG(r.rating_facility) AS avg_facility,
                               AVG(' . OVERALL_SQL . ') AS avg_overall
                        FROM coffee_shops s LEFT JOIN reviews r ON r.shop_id = s.id
                        GROUP BY s.id
                        ORDER BY COUNT(r.id) = 0, AVG(' . OVERALL_SQL . ') DESC, s.name')->fetchAll();

$pageTitle = 'Hasil survei';
$activeNav = 'stats';
include __DIR__ . '/includes/header.php';
?>

<section class="section">
    <div class="container">
        <h1 class="h1-md">Hasil survei</h1>
        <p class="lead-sm">Rangkuman jawaban semua responden, dihitung otomatis dari database.</p>

        <?php if ($totalResp === 0): ?>
            <div class="empty">
                <h2>Belum ada jawaban masuk</h2>
                <p>Hasil survei akan muncul setelah ada yang mengisi formulir rating.</p>
                <a class="btn" href="rate.php">Isi formulir</a>
            </div>
        <?php else: ?>

            <h2 class="section-title">Perbandingan coffee shop</h2>
            <div class="table-wrap">
                <table>
                    <thead>
                    <tr><th>Peringkat</th><th>Coffee shop</th><th>Responden</th><th>Rasa kopi</th><th>Fasilitas</th><th>Rata-rata</th></tr>
                    </thead>
                    <tbody>
                    <?php $rank = 0; foreach ($compare as $c): ?>
                        <tr>
                            <td><?= (int) $c['total'] > 0 ? ++$rank : '-' ?></td>
                            <td><a href="shop.php?id=<?= (int) $c['id'] ?>"><strong><?= e($c['name']) ?></strong></a></td>
                            <td><?= (int) $c['total'] ?></td>
                            <td><?= e(score($c['avg_taste'])) ?></td>
                            <td><?= e(score($c['avg_facility'])) ?></td>
                            <td><strong><?= e(score($c['avg_overall'])) ?></strong></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <h2 class="section-title">Jawaban responden</h2>
            <form class="filters filters-inline" method="get" action="statistik.php">
                <div class="field">
                    <label for="shop">Tampilkan untuk</label>
                    <select id="shop" name="shop">
                        <option value="0">Semua coffee shop</option>
                        <?php foreach ($shops as $s): ?>
                            <option value="<?= (int) $s['id'] ?>" <?= (int) $s['id'] === $shopId ? 'selected' : '' ?>><?= e($s['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button class="btn" type="submit">Terapkan</button>
            </form>

            <?php if ($shownResp === 0): ?>
                <div class="empty"><p>Belum ada responden untuk coffee shop ini.</p></div>
            <?php else: ?>
                <p class="hint">Berdasarkan <?= $shownResp ?> responden. Batang tebal menandai jawaban terbanyak.</p>
                <div class="survey-grid">
                    <?= survey_panels($pdo, $filter) ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
