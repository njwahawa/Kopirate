<?php
require __DIR__ . '/includes/functions.php';

$pdo = db();
$id  = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM coffee_shops WHERE id = :id');
$stmt->execute([':id' => $id]);
$shop = $stmt->fetch();

if (!$shop) {
    http_response_code(404);
    $pageTitle = 'Coffee shop tidak ditemukan';
    include __DIR__ . '/includes/header.php';
    echo '<section class="section"><div class="container empty"><h1>Coffee shop tidak ditemukan</h1>'
        . '<p>Mungkin sudah dihapus.</p><a class="btn" href="index.php#daftar">Kembali ke daftar</a></div></section>';
    include __DIR__ . '/includes/footer.php';
    exit;
}

/* ---------- Rata-rata nilai ---------- */
$avgCols = [];
foreach (array_keys(CRITERIA) as $key) {
    $avgCols[] = "AVG($key) AS $key";
}
$stmt = $pdo->prepare('SELECT COUNT(*) AS total, ' . implode(', ', $avgCols) . ' FROM reviews WHERE shop_id = :id');
$stmt->execute([':id' => $id]);
$agg   = $stmt->fetch();
$total = (int) $agg['total'];

$overall = null;
if ($total > 0) {
    $sum = 0;
    foreach (array_keys(CRITERIA) as $key) {
        $sum += (float) $agg[$key];
    }
    $overall = $sum / count(CRITERIA);
}

/* ---------- Penilaian terbaru ---------- */
$stmt = $pdo->prepare('SELECT r.*, ' . OVERALL_SQL . ' AS overall
                       FROM reviews r WHERE r.shop_id = :id
                       ORDER BY r.created_at DESC, r.id DESC LIMIT 10');
$stmt->execute([':id' => $id]);
$latest = $stmt->fetchAll();

$pageTitle = $shop['name'];
include __DIR__ . '/includes/header.php';
?>

<section class="shop-hero">
    <div class="container shop-hero-grid">
        <div>
            <a class="back-link" href="index.php#daftar">Kembali ke daftar</a>
            <h1><?= e($shop['name']) ?></h1>
            <?php if ($shop['location']): ?><p class="meta-lg"><?= e($shop['location']) ?></p><?php endif; ?>
            <?php if ($shop['description']): ?><p class="shop-desc"><?= e($shop['description']) ?></p><?php endif; ?>
            <a class="btn" href="rate.php?shop=<?= (int) $shop['id'] ?>">Beri rating coffee shop ini</a>
        </div>

        <div class="score-badge">
            <?php if ($total > 0): ?>
                <div class="score-num"><?= e(score($overall)) ?></div>
                <?= beans($overall, 'beans-lg') ?>
                <p class="meta">dari <?= $total ?> responden</p>
            <?php else: ?>
                <div class="score-num">-</div>
                <p class="meta">Belum ada responden</p>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">

        <?php if (isset($_GET['sent'])): ?>
            <div class="alert alert-ok" role="status"><strong>Terima kasih!</strong> Jawabanmu sudah tersimpan dan ikut dihitung.</div>
        <?php endif; ?>

        <?php if ($total === 0): ?>
            <div class="empty">
                <h2>Belum ada yang menilai coffee shop ini</h2>
                <p>Kamu bisa jadi yang pertama.</p>
                <a class="btn" href="rate.php?shop=<?= (int) $shop['id'] ?>">Beri rating</a>
            </div>
        <?php else: ?>
            <div class="panel panel-wide">
                <h2>Nilai rata-rata</h2>
                <?php foreach (CRITERIA as $key => $meta): $val = (float) $agg[$key]; ?>
                    <div class="bar-row">
                        <span class="bar-label"><?= e($meta['short']) ?></span>
                        <div class="bar" role="img" aria-label="<?= e($meta['short']) ?>: <?= e(score($val)) ?> dari 5">
                            <span style="width:<?= round($val / 5 * 100) ?>%"></span>
                        </div>
                        <span class="bar-val"><?= e(score($val)) ?></span>
                    </div>
                <?php endforeach; ?>
                <p class="hint">Skala 1 (Sangat Tidak Baik) sampai 5 (Sangat Baik).</p>
            </div>

            <h2 class="section-title">Kebiasaan pengunjung</h2>
            <p class="hint">Persentase jawaban dari <?= $total ?> responden. Batang tebal menandai jawaban terbanyak.</p>
            <div class="survey-grid">
                <?= survey_panels($pdo, $id) ?>
            </div>

            <h2 class="section-title">Penilaian terbaru</h2>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>Nama</th><th>Usia</th><th>Tujuan datang</th><th>Rasa</th><th>Fasilitas</th><th>Tanggal</th></tr></thead>
                    <tbody>
                    <?php foreach ($latest as $r): ?>
                        <tr>
                            <td><strong><?= e($r['reviewer_name']) ?></strong></td>
                            <td><?= e($r['age_group']) ?></td>
                            <td><?= e($r['purpose']) ?></td>
                            <td><?= (int) $r['rating_taste'] ?> / 5</td>
                            <td><?= (int) $r['rating_facility'] ?> / 5</td>
                            <td><?= e(tanggal($r['created_at'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
