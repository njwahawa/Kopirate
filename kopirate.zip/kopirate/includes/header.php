<?php
/**
 * Variabel yang bisa di-set sebelum include:
 *   $pageTitle  - judul tab
 *   $activeNav  - home | rate | admin
 *   $base       - awalan path ('' untuk root, '../' untuk folder admin)
 *   $isAdmin    - true untuk menu admin
 */
$base      = $base      ?? '';
$pageTitle = $pageTitle ?? APP_NAME;
$activeNav = $activeNav ?? '';
$isAdmin   = $isAdmin   ?? false;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle) ?> | <?= e(APP_NAME) ?></title>
    <meta name="description" content="Rating coffee shop di Samarinda dari sudut pandang anak kos: rasa kopi, fasilitas, harga, dan kebiasaan nongkrong.">
    <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%23FFD0DB'/%3E%3Ctext y='.72em' x='50' text-anchor='middle' font-size='62'%3E%E2%98%95%3C/text%3E%3C/svg%3E">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500..800&family=Courier+Prime:wght@400;700&family=Figtree:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= e($base) ?>assets/css/style.css">
</head>
<body>
<a class="skip-link" href="#konten">Lewati ke konten</a>

<header class="site-header">
    <div class="container header-inner">
        <a class="brand" href="<?= e($base) ?>index.php" aria-label="<?= e(APP_NAME) ?> - beranda">
            <span class="brand-mark" aria-hidden="true">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#4E2C13" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M4 9h12v5a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5V9z"/>
                    <path d="M16 10h1.5a2.5 2.5 0 0 1 0 5H16"/>
                    <path d="M8 3.5c0 1.2 1 1.2 1 2.5M12 3.5c0 1.2 1 1.2 1 2.5"/>
                </svg>
            </span>
            <span>
                <span class="brand-name">KopiRate</span>
                <span class="brand-sub">Samarinda</span>
            </span>
        </a>

        <nav class="nav" aria-label="Menu utama">
            <?php if ($isAdmin): ?>
                <a href="<?= e($base) ?>admin/index.php" <?= $activeNav === 'admin' ? 'aria-current="page"' : '' ?>>Dasbor</a>
                <a href="<?= e($base) ?>admin/shop_form.php">Tambah kedai</a>
                <a href="<?= e($base) ?>index.php">Lihat situs</a>
                <a href="<?= e($base) ?>admin/logout.php" class="nav-cta">Keluar</a>
            <?php else: ?>
                <a href="<?= e($base) ?>index.php" <?= $activeNav === 'home' ? 'aria-current="page"' : '' ?>>Beranda</a>
                <a href="<?= e($base) ?>index.php#daftar">Coffee shop</a>
                <a href="<?= e($base) ?>statistik.php" <?= $activeNav === 'stats' ? 'aria-current="page"' : '' ?>>Hasil survei</a>
                <a href="<?= e($base) ?>admin/login.php" <?= $activeNav === 'admin' ? 'aria-current="page"' : '' ?>>Admin</a>
                <a href="<?= e($base) ?>rate.php" class="nav-cta">Beri rating</a>
            <?php endif; ?>
        </nav>
    </div>
</header>

<main id="konten">
