<?php
declare(strict_types=1);

require_once __DIR__ . '/../config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* =====================================================================
 *  DEFINISI PERTANYAAN - sama dengan Google Forms.
 *  Mau ubah teks / pilihan jawaban? Cukup ubah di sini.
 *  (Kalau menambah pertanyaan baru, tambahkan juga kolomnya di tabel reviews.)
 * ===================================================================== */

// Skala penilaian: "1 = Sangat Tidak Baik ... 5 = Sangat Baik"
const RATING_WORDS = [
    1 => 'Sangat Tidak Baik',
    2 => 'Tidak Baik',
    3 => 'Cukup',
    4 => 'Baik',
    5 => 'Sangat Baik',
];

// Pertanyaan bernilai 1-5 (kolom di tabel reviews)
const CRITERIA = [
    'rating_taste' => [
        'short' => 'Rasa kopi',
        'label' => 'Rasa Kopi',
        'hint'  => 'Bagaimana penilaian kamu terhadap rasa kopi tersebut',
    ],
    'rating_facility' => [
        'short' => 'Fasilitas & kenyamanan',
        'label' => 'Fasilitas dan kenyamanan',
        'hint'  => 'Bagaimana menurut Anda tentang fasilitas dan kenyamanan coffe shop tersebut',
    ],
];

// Pertanyaan pilihan ganda. group: profile (halaman 1) / habit (halaman 2)
// layout: inline (pilihan pendek) / stack (pilihan panjang, ditumpuk)
const CHOICE_QUESTIONS = [
    'age_group' => [
        'group'   => 'profile', 'layout' => 'inline',
        'short'   => 'Usia',
        'label'   => 'Usia',
        'options' => ['<16 tahun', '17-20 tahun', '21-25 tahun', '>25 tahun'],
    ],
    'visit_frequency' => [
        'group'   => 'profile', 'layout' => 'inline',
        'short'   => 'Seberapa sering nongkrong',
        'label'   => 'Seberapa sering kamu mengunjungi atau nongkrong di coffe shop ?',
        'options' => ['1 kali sehari', '2 kali seminggu', '1 kali sebulan', 'kadang-kadang', 'tidak pernah'],
    ],
    'avg_spend' => [
        'group'   => 'profile', 'layout' => 'inline',
        'short'   => 'Rata-rata harga minuman',
        'label'   => 'Berapa rata-rata harga minuman yang Anda beli ?',
        'options' => ['<Rp15.000', 'Rp15.000 - Rp 25.000', 'Rp25.000 - Rp35.000', '>Rp35.000'],
    ],
    'reason' => [
        'group'   => 'habit', 'layout' => 'stack',
        'short'   => 'Alasan memilih tempat',
        'label'   => 'Apa alasan Anda untuk memilih tempat tersebut dibanding yang lain',
        'options' => [
            'Harga terjangkau',
            'Wifi kencang dan colokan banyak',
            'Lokasi dekat kampus atau kos',
            'Susana tenang untuk belajar',
            'Rasa kopi atau makanannya enak',
        ],
    ],
    'parking' => [
        'group'   => 'habit', 'layout' => 'stack',
        'short'   => 'Kemudahan parkir',
        'label'   => 'Bagaimana tingkat kemudahan dan kenyamanan area parkir disana ?',
        'options' => ['Sangat mudah & gratis atau murah', 'Cukup mudah, bayar standar', 'Sulit atau lahan terbatas'],
    ],
    'visit_time' => [
        'group'   => 'habit', 'layout' => 'inline',
        'short'   => 'Jam kunjungan',
        'label'   => 'Jam berapa anda biasanya Anda mengunjungi coffe shop tersebut ?',
        'options' => ['pagi (08.00 - 12.00)', 'Siang/sore (12.00 - 18.00)', 'Malam (18.00 - 24.00)', 'Dini hari / 24 jam'],
    ],
    'duration' => [
        'group'   => 'habit', 'layout' => 'inline',
        'short'   => 'Lama di coffee shop',
        'label'   => 'Berapa lama rata-rata durasi anda menghabiskan waktu di coffe shop tersebut ?',
        'options' => ['<1 jam', '1 - 3 jam', '3 - 5 jam', '> 5 jam'],
    ],
    'non_coffee' => [
        'group'   => 'habit', 'layout' => 'stack',
        'short'   => 'Variasi menu non-kopi',
        'label'   => 'Jika tidak memesan kopi, seberapa banyak variasi menu non-kopi (seperti teh, matcha atau mocktail) yang ditawarkan?',
        'options' => ['Sangat bervariasi dan terjangkau', 'Cukup bervariasi', 'Sangat sedikit pilihan'],
    ],
    'purpose' => [
        'group'   => 'habit', 'layout' => 'stack',
        'short'   => 'Tujuan utama datang',
        'label'   => 'Apa tujuan utama Anda saat datang ke coffe shop tersebut?',
        'options' => ['Nugas/belajar mandiri', 'Diskusi kelompok/rapat organisasi', 'Sekedar nongkrong/mengobrol', 'Me time/bersantai'],
    ],
    'noise' => [
        'group'   => 'habit', 'layout' => 'stack',
        'short'   => 'Kebisingan saat nugas',
        'label'   => 'Apakah tingkat kebisingan (musik/keramaian) di coffe shop tersebut mendukung fokus anda saat nugas?',
        'options' => ['Ya, sangat mendukung', 'Terkadang terlalu bising', 'Tidak mendukung sama sekali'],
    ],
];

// Rata-rata dua penilaian per responden (alias tabel: r)
const OVERALL_SQL = '((r.rating_taste + r.rating_facility) / 2)';

/* ------------------------------------------------------------------
 *  Database (PDO)
 * ------------------------------------------------------------------ */
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        } catch (PDOException $ex) {
            http_response_code(500);
            exit('<h1>Koneksi database gagal</h1><p>Pastikan MySQL di XAMPP sudah <b>Start</b> dan file '
                . '<code>database.sql</code> sudah di-import lewat phpMyAdmin.</p><p><small>'
                . htmlspecialchars($ex->getMessage(), ENT_QUOTES, 'UTF-8') . '</small></p>');
        }
    }
    return $pdo;
}

/* ------------------------------------------------------------------
 *  Keamanan & format
 * ------------------------------------------------------------------ */
function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_valid(): bool
{
    return isset($_POST['csrf'], $_SESSION['csrf'])
        && hash_equals($_SESSION['csrf'], (string) $_POST['csrf']);
}

function score($value): string
{
    return $value === null ? '-' : number_format((float) $value, 1, ',', '.');
}

function tanggal(string $datetime): string
{
    static $bulan = [1 => 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    $time = strtotime($datetime);
    if (!$time) {
        return '';
    }
    return date('j', $time) . ' ' . $bulan[(int) date('n', $time)] . ' ' . date('Y', $time);
}

function cover_tone(int $id): string
{
    return ['pink', 'sage', 'cream'][$id % 3];
}

/* ------------------------------------------------------------------
 *  Ikon biji kopi (dipakai sebagai "bintang" rating)
 * ------------------------------------------------------------------ */
function bean_svg(): string
{
    return '<svg class="bean" viewBox="0 0 24 24" aria-hidden="true" focusable="false">'
        . '<g transform="rotate(-32 12 12)">'
        . '<ellipse class="bean-body" cx="12" cy="12" rx="6.6" ry="9.6"/>'
        . '<path class="bean-crease" d="M12 2.6C8.6 6.4 15.4 9.4 12 12s3.4 5.6 0 9.4"/>'
        . '</g></svg>';
}

/** Rating tampilan (bisa pecahan, mis. 4,3 biji kopi). */
function beans($value, string $size = ''): string
{
    $value = max(0.0, min(5.0, (float) $value));
    $pct   = round($value / 5 * 100, 1);
    $row   = str_repeat(bean_svg(), 5);
    return '<span class="beans ' . e($size) . '" role="img" aria-label="Rating ' . e(score($value)) . ' dari 5">'
        . '<span class="beans-row beans-empty">' . $row . '</span>'
        . '<span class="beans-row beans-fill" style="width:' . $pct . '%">' . $row . '</span>'
        . '</span>';
}

/* ------------------------------------------------------------------
 *  Statistik jawaban (dipakai halaman detail kedai & hasil survei)
 * ------------------------------------------------------------------ */

/** Jumlah jawaban per pilihan untuk satu pertanyaan. $shopId null = semua kedai. */
function distribution(PDO $pdo, string $column, ?int $shopId = null): array
{
    if (!isset(CHOICE_QUESTIONS[$column])) {
        throw new InvalidArgumentException('Kolom tidak dikenal.');
    }
    $counts = array_fill_keys(CHOICE_QUESTIONS[$column]['options'], 0);

    $sql  = "SELECT $column AS answer, COUNT(*) AS c FROM reviews" . ($shopId ? ' WHERE shop_id = :id' : '') . " GROUP BY $column";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($shopId ? [':id' => $shopId] : []);
    foreach ($stmt->fetchAll() as $row) {
        if (array_key_exists($row['answer'], $counts)) {
            $counts[$row['answer']] = (int) $row['c'];
        }
    }
    return $counts;
}

/** Jawaban terbanyak untuk tiap kedai: [shop_id => jawaban]. */
function top_answer_by_shop(PDO $pdo, string $column): array
{
    if (!isset(CHOICE_QUESTIONS[$column])) {
        throw new InvalidArgumentException('Kolom tidak dikenal.');
    }
    $rows = $pdo->query("SELECT shop_id, $column AS answer, COUNT(*) AS c
                         FROM reviews GROUP BY shop_id, $column
                         ORDER BY shop_id, c DESC")->fetchAll();
    $top = [];
    foreach ($rows as $row) {
        if (!isset($top[$row['shop_id']])) {
            $top[$row['shop_id']] = $row['answer'];
        }
    }
    return $top;
}

/** Satu panel batang persentase untuk satu pertanyaan. */
function render_distribution(string $title, array $counts): string
{
    $total = array_sum($counts);
    $max   = $counts ? max($counts) : 0;

    $html = '<div class="panel"><h3>' . e($title) . '</h3>';
    foreach ($counts as $option => $c) {
        $pct  = $total > 0 ? (int) round($c / $total * 100) : 0;
        $lead = ($max > 0 && $c === $max) ? ' is-top' : '';
        $html .= '<div class="dist-row">'
            . '<div class="dist-top"><span>' . e($option) . '</span><b>' . $pct . '% <small>(' . $c . ')</small></b></div>'
            . '<div class="bar bar-dist' . $lead . '" role="img" aria-label="' . e($option) . ': ' . $c . ' responden, ' . $pct . ' persen">'
            . '<span style="width:' . $pct . '%"></span></div></div>';
    }
    return $html . '</div>';
}

/** Semua panel pertanyaan pilihan ganda (dipecah profil / kebiasaan). */
function survey_panels(PDO $pdo, ?int $shopId = null, string $group = ''): string
{
    $html = '';
    foreach (CHOICE_QUESTIONS as $column => $q) {
        if ($group !== '' && $q['group'] !== $group) {
            continue;
        }
        $html .= render_distribution($q['short'], distribution($pdo, $column, $shopId));
    }
    return $html;
}
