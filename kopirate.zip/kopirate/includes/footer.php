<?php $base = $base ?? ''; ?>
</main>

<footer class="site-footer">
    <div class="container footer-inner">
        <div>
            <strong class="footer-brand">KopiRate Samarinda</strong>
            <p>Coffee shop ter-worth-it untuk kantong anak kos.</p>
        </div>
        <p class="footer-note">Perancangan aplikasi rating coffee shop di Samarinda berbasis web.</p>
    </div>
</footer>

<script src="<?= e($base) ?>assets/js/app.js"></script>
</body>
</html>
