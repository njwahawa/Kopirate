# KopiRate Samarinda

Aplikasi web rating coffee shop di Samarinda (PHP + MySQL, jalan di XAMPP).
Pertanyaan formnya mengikuti Google Forms "Coffe Shop ter Worth-it Untuk Kantong Anak Kos".

## Cara menjalankan
1. Buka **XAMPP**, klik **Start** pada **Apache** dan **MySQL**.
2. Salin folder `kopirate` ke `C:\xampp\htdocs\`.
3. Buka `http://localhost/phpmyadmin` -> tab **Import**:
   - import `database.sql` (wajib, membuat database + 5 coffee shop)
   - import `data_contoh.sql` (opsional, 30 jawaban FIKTIF untuk mengetes tampilan)
4. Buka `http://localhost/kopirate/`.

Mau mengosongkan data contoh? Import ulang `database.sql` (data lama ikut terhapus).

## Halaman
| Alamat | Fungsi |
|---|---|
| `/kopirate/` | Beranda: peringkat, daftar coffee shop, pencarian & urutan |
| `/kopirate/rate.php` | Form rating (14 pertanyaan sesuai Google Forms) |
| `/kopirate/shop.php?id=1` | Detail coffee shop: nilai + persentase jawaban |
| `/kopirate/statistik.php` | Hasil survei semua responden + perbandingan |
| `/kopirate/admin/` | Admin: kelola coffee shop, hapus jawaban, unduh CSV |

Login admin bawaan: `admin` / `admin123` (ubah di `config.php`).

## Struktur
```
kopirate/
  config.php            <- pengaturan database & login admin
  database.sql          <- struktur tabel + 5 coffee shop
  data_contoh.sql       <- data fiktif (opsional)
  index.php  rate.php  shop.php  statistik.php
  includes/functions.php  <- SEMUA pertanyaan & pilihan jawaban ada di sini
  includes/header.php  footer.php
  assets/css/style.css  <- tampilan (palet warna di :root)
  assets/js/app.js
  admin/                <- login, dasbor, form coffee shop, hapus, export CSV
```

## Mengubah pertanyaan
Semua teks pertanyaan dan pilihan jawaban ada di `includes/functions.php`
(`CRITERIA` untuk skala 1-5, `CHOICE_QUESTIONS` untuk pilihan ganda).
Form, validasi, statistik, dan ekspor CSV otomatis mengikuti.
Kalau menambah pertanyaan baru, tambahkan juga kolomnya di tabel `reviews`.
