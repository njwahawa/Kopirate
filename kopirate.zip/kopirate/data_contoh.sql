-- =====================================================================
--  DATA CONTOH (FIKTIF) - hanya untuk mengetes tampilan.
--  Nama responden dan nilai di bawah ini dibuat secara acak dan TIDAK
--  mewakili penilaian asli terhadap coffee shop mana pun.
--
--  Cara pakai: import SETELAH database.sql.
--  Hapus lewat Admin, atau import ulang database.sql untuk mengosongkan.
-- =====================================================================
USE kopirate_samarinda;

INSERT INTO reviews
  (shop_id, reviewer_name, age_group, visit_frequency, avg_spend, rating_taste, rating_facility,
   reason, parking, visit_time, duration, non_coffee, purpose, noise)
VALUES
(1, 'Rina', '21-25 tahun', '1 kali sebulan', '<Rp15.000', 5, 4, 'Wifi kencang dan colokan banyak', 'Cukup mudah, bayar standar', 'pagi (08.00 - 12.00)', '1 - 3 jam', 'Cukup bervariasi', 'Diskusi kelompok/rapat organisasi', 'Tidak mendukung sama sekali'),
(1, 'Dimas', '21-25 tahun', '1 kali sehari', '<Rp15.000', 3, 3, 'Lokasi dekat kampus atau kos', 'Cukup mudah, bayar standar', 'Malam (18.00 - 24.00)', '<1 jam', 'Cukup bervariasi', 'Diskusi kelompok/rapat organisasi', 'Terkadang terlalu bising'),
(1, 'Salsa', '21-25 tahun', '1 kali sebulan', 'Rp15.000 - Rp 25.000', 1, 3, 'Susana tenang untuk belajar', 'Cukup mudah, bayar standar', 'Malam (18.00 - 24.00)', '1 - 3 jam', 'Sangat bervariasi dan terjangkau', 'Nugas/belajar mandiri', 'Ya, sangat mendukung'),
(1, 'Fajar', '21-25 tahun', '1 kali sehari', '<Rp15.000', 5, 3, 'Rasa kopi atau makanannya enak', 'Sulit atau lahan terbatas', 'pagi (08.00 - 12.00)', '<1 jam', 'Sangat bervariasi dan terjangkau', 'Diskusi kelompok/rapat organisasi', 'Ya, sangat mendukung'),
(1, 'Aldi', '21-25 tahun', '1 kali sebulan', '<Rp15.000', 4, 3, 'Rasa kopi atau makanannya enak', 'Sangat mudah & gratis atau murah', 'Malam (18.00 - 24.00)', '<1 jam', 'Cukup bervariasi', 'Diskusi kelompok/rapat organisasi', 'Terkadang terlalu bising'),
(1, 'Nadia', '17-20 tahun', '1 kali sebulan', 'Rp15.000 - Rp 25.000', 5, 5, 'Harga terjangkau', 'Cukup mudah, bayar standar', 'Malam (18.00 - 24.00)', '<1 jam', 'Cukup bervariasi', 'Nugas/belajar mandiri', 'Tidak mendukung sama sekali'),
(2, 'Bayu', '21-25 tahun', '1 kali sehari', '>Rp35.000', 3, 3, 'Lokasi dekat kampus atau kos', 'Cukup mudah, bayar standar', 'Siang/sore (12.00 - 18.00)', '3 - 5 jam', 'Sangat sedikit pilihan', 'Sekedar nongkrong/mengobrol', 'Terkadang terlalu bising'),
(2, 'Putri', '17-20 tahun', '1 kali sebulan', 'Rp15.000 - Rp 25.000', 2, 4, 'Wifi kencang dan colokan banyak', 'Sangat mudah & gratis atau murah', 'pagi (08.00 - 12.00)', '1 - 3 jam', 'Sangat bervariasi dan terjangkau', 'Nugas/belajar mandiri', 'Terkadang terlalu bising'),
(2, 'Reza', '21-25 tahun', '2 kali seminggu', 'Rp15.000 - Rp 25.000', 4, 3, 'Rasa kopi atau makanannya enak', 'Cukup mudah, bayar standar', 'Siang/sore (12.00 - 18.00)', '1 - 3 jam', 'Sangat sedikit pilihan', 'Sekedar nongkrong/mengobrol', 'Ya, sangat mendukung'),
(2, 'Wulan', '21-25 tahun', '2 kali seminggu', '<Rp15.000', 4, 4, 'Rasa kopi atau makanannya enak', 'Sulit atau lahan terbatas', 'Siang/sore (12.00 - 18.00)', '3 - 5 jam', 'Sangat bervariasi dan terjangkau', 'Nugas/belajar mandiri', 'Terkadang terlalu bising'),
(2, 'Hendra', '21-25 tahun', '2 kali seminggu', 'Rp15.000 - Rp 25.000', 5, 5, 'Wifi kencang dan colokan banyak', 'Sulit atau lahan terbatas', 'Malam (18.00 - 24.00)', '3 - 5 jam', 'Sangat bervariasi dan terjangkau', 'Diskusi kelompok/rapat organisasi', 'Ya, sangat mendukung'),
(2, 'Melati', '21-25 tahun', '2 kali seminggu', '<Rp15.000', 5, 4, 'Rasa kopi atau makanannya enak', 'Cukup mudah, bayar standar', 'Malam (18.00 - 24.00)', '1 - 3 jam', 'Sangat bervariasi dan terjangkau', 'Me time/bersantai', 'Ya, sangat mendukung'),
(3, 'Ilham', '17-20 tahun', '1 kali sebulan', 'Rp15.000 - Rp 25.000', 5, 2, 'Susana tenang untuk belajar', 'Cukup mudah, bayar standar', 'Siang/sore (12.00 - 18.00)', '1 - 3 jam', 'Sangat sedikit pilihan', 'Sekedar nongkrong/mengobrol', 'Ya, sangat mendukung'),
(3, 'Citra', '21-25 tahun', '2 kali seminggu', '<Rp15.000', 3, 3, 'Susana tenang untuk belajar', 'Cukup mudah, bayar standar', 'pagi (08.00 - 12.00)', '1 - 3 jam', 'Cukup bervariasi', 'Sekedar nongkrong/mengobrol', 'Tidak mendukung sama sekali'),
(3, 'Anisa', '17-20 tahun', '2 kali seminggu', 'Rp15.000 - Rp 25.000', 2, 4, 'Harga terjangkau', 'Cukup mudah, bayar standar', 'Dini hari / 24 jam', '<1 jam', 'Sangat bervariasi dan terjangkau', 'Diskusi kelompok/rapat organisasi', 'Tidak mendukung sama sekali'),
(3, 'Rizky', '21-25 tahun', '1 kali sebulan', '<Rp15.000', 2, 2, 'Harga terjangkau', 'Sangat mudah & gratis atau murah', 'Malam (18.00 - 24.00)', '<1 jam', 'Sangat bervariasi dan terjangkau', 'Nugas/belajar mandiri', 'Ya, sangat mendukung'),
(3, 'Dewi', '21-25 tahun', 'kadang-kadang', 'Rp15.000 - Rp 25.000', 4, 4, 'Rasa kopi atau makanannya enak', 'Sulit atau lahan terbatas', 'pagi (08.00 - 12.00)', '<1 jam', 'Sangat bervariasi dan terjangkau', 'Nugas/belajar mandiri', 'Ya, sangat mendukung'),
(3, 'Farhan', '21-25 tahun', 'kadang-kadang', 'Rp25.000 - Rp35.000', 3, 1, 'Harga terjangkau', 'Sulit atau lahan terbatas', 'Siang/sore (12.00 - 18.00)', '1 - 3 jam', 'Sangat bervariasi dan terjangkau', 'Sekedar nongkrong/mengobrol', 'Tidak mendukung sama sekali'),
(4, 'Tiara', '21-25 tahun', '1 kali sebulan', 'Rp15.000 - Rp 25.000', 5, 5, 'Wifi kencang dan colokan banyak', 'Cukup mudah, bayar standar', 'Dini hari / 24 jam', '3 - 5 jam', 'Cukup bervariasi', 'Sekedar nongkrong/mengobrol', 'Ya, sangat mendukung'),
(4, 'Yoga', '21-25 tahun', '2 kali seminggu', 'Rp25.000 - Rp35.000', 2, 5, 'Susana tenang untuk belajar', 'Sulit atau lahan terbatas', 'Siang/sore (12.00 - 18.00)', '3 - 5 jam', 'Cukup bervariasi', 'Sekedar nongkrong/mengobrol', 'Ya, sangat mendukung'),
(4, 'Nabila', '17-20 tahun', '2 kali seminggu', 'Rp15.000 - Rp 25.000', 5, 3, 'Susana tenang untuk belajar', 'Sangat mudah & gratis atau murah', 'Malam (18.00 - 24.00)', '3 - 5 jam', 'Sangat bervariasi dan terjangkau', 'Sekedar nongkrong/mengobrol', 'Ya, sangat mendukung'),
(4, 'Galih', '21-25 tahun', '2 kali seminggu', '<Rp15.000', 4, 4, 'Susana tenang untuk belajar', 'Cukup mudah, bayar standar', 'pagi (08.00 - 12.00)', '<1 jam', 'Cukup bervariasi', 'Sekedar nongkrong/mengobrol', 'Terkadang terlalu bising'),
(4, 'Sinta', '17-20 tahun', '1 kali sehari', 'Rp15.000 - Rp 25.000', 5, 5, 'Susana tenang untuk belajar', 'Sangat mudah & gratis atau murah', 'Siang/sore (12.00 - 18.00)', '1 - 3 jam', 'Cukup bervariasi', 'Sekedar nongkrong/mengobrol', 'Terkadang terlalu bising'),
(4, 'Bagas', '17-20 tahun', '1 kali sehari', 'Rp15.000 - Rp 25.000', 4, 3, 'Susana tenang untuk belajar', 'Sulit atau lahan terbatas', 'pagi (08.00 - 12.00)', '1 - 3 jam', 'Sangat bervariasi dan terjangkau', 'Nugas/belajar mandiri', 'Ya, sangat mendukung'),
(5, 'Lestari', '17-20 tahun', 'kadang-kadang', '<Rp15.000', 3, 4, 'Wifi kencang dan colokan banyak', 'Cukup mudah, bayar standar', 'Siang/sore (12.00 - 18.00)', '<1 jam', 'Sangat bervariasi dan terjangkau', 'Nugas/belajar mandiri', 'Tidak mendukung sama sekali'),
(5, 'Arif', '17-20 tahun', '2 kali seminggu', 'Rp15.000 - Rp 25.000', 4, 5, 'Susana tenang untuk belajar', 'Cukup mudah, bayar standar', 'Siang/sore (12.00 - 18.00)', '3 - 5 jam', 'Sangat bervariasi dan terjangkau', 'Nugas/belajar mandiri', 'Ya, sangat mendukung'),
(5, 'Mira', '17-20 tahun', '1 kali sebulan', 'Rp25.000 - Rp35.000', 5, 5, 'Rasa kopi atau makanannya enak', 'Sangat mudah & gratis atau murah', 'Siang/sore (12.00 - 18.00)', '1 - 3 jam', 'Sangat sedikit pilihan', 'Nugas/belajar mandiri', 'Terkadang terlalu bising'),
(5, 'Taufik', '17-20 tahun', '2 kali seminggu', '<Rp15.000', 4, 5, 'Wifi kencang dan colokan banyak', 'Sangat mudah & gratis atau murah', 'pagi (08.00 - 12.00)', '1 - 3 jam', 'Sangat bervariasi dan terjangkau', 'Nugas/belajar mandiri', 'Terkadang terlalu bising'),
(5, 'Vina', '17-20 tahun', '2 kali seminggu', '<Rp15.000', 3, 5, 'Rasa kopi atau makanannya enak', 'Sangat mudah & gratis atau murah', 'Dini hari / 24 jam', '3 - 5 jam', 'Sangat sedikit pilihan', 'Diskusi kelompok/rapat organisasi', 'Ya, sangat mendukung'),
(5, 'Eko', '21-25 tahun', '1 kali sebulan', '<Rp15.000', 2, 3, 'Rasa kopi atau makanannya enak', 'Sulit atau lahan terbatas', 'Siang/sore (12.00 - 18.00)', '> 5 jam', 'Cukup bervariasi', 'Diskusi kelompok/rapat organisasi', 'Ya, sangat mendukung');
