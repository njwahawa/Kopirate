/* KopiRate Samarinda - interaksi form rating */
document.addEventListener('DOMContentLoaded', function () {
    var form = document.querySelector('.rate-form');
    var words = {};
    try { words = JSON.parse(form.getAttribute('data-words') || '{}'); } catch (e) { words = {}; }
    var inputs = document.querySelectorAll('.bean-input input[type="radio"]');
    if (!inputs.length) { return; }

    var liveBeans = document.querySelector('#live-beans .beans-fill');
    var liveNumber = document.getElementById('live-number');

    function updateLive() {
        var groups = {};
        inputs.forEach(function (input) {
            if (input.checked) { groups[input.name] = parseInt(input.value, 10); }
        });
        var names = Object.keys(groups);
        if (!names.length) { return; }

        var sum = 0;
        names.forEach(function (n) { sum += groups[n]; });
        var avg = sum / names.length;

        if (liveBeans) { liveBeans.style.width = (avg / 5 * 100) + '%'; }
        if (liveNumber) { liveNumber.textContent = avg.toFixed(1).replace('.', ','); }
    }

    inputs.forEach(function (input) {
        input.addEventListener('change', function () {
            var out = input.closest('.rate-control').querySelector('.rate-word');
            if (out) { out.textContent = input.value + ' = ' + (words[input.value] || ''); }
            updateLive();
        });
        if (input.checked) { input.dispatchEvent(new Event('change')); }
    });
});
