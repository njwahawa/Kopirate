<?php
/**
 * KopiRate Samarinda - konfigurasi
 * Default XAMPP: user "root" dengan password kosong.
 */

date_default_timezone_set('Asia/Makassar'); // WITA (Samarinda)

// --- Database ---
define('DB_HOST', 'localhost');
define('DB_NAME', 'kopirate_samarinda');
define('DB_USER', 'root');
define('DB_PASS', '');

// --- Login halaman admin (GANTI sebelum dipublikasikan) ---
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', 'admin123');

define('APP_NAME', 'KopiRate Samarinda');
