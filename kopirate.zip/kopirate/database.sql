-- =====================================================================
--  KopiRate Samarinda - database (mengikuti Google Forms
--  "Coffe Shop ter Worth-it Untuk Kantong Anak Kos")
--
--  Cara pakai (XAMPP): http://localhost/phpmyadmin -> tab "Import"
--  -> pilih file ini -> klik "Import". Database dibuat otomatis.
--  Data contoh untuk mengetes tampilan ada di file: data_contoh.sql
-- =====================================================================

CREATE DATABASE IF NOT EXISTS kopirate_samarinda
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE kopirate_samarinda;

-- Hati-hati: dua baris ini menghapus data lama kalau file di-import ulang.
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS coffee_shops;

-- ---------------------------------------------------------------------
--  Daftar coffee shop (pilihan pada pertanyaan
--  "Coffe shop apa yang sering Anda kunjungi")
-- ---------------------------------------------------------------------
CREATE TABLE coffee_shops (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(120) NOT NULL,
  location    VARCHAR(255) DEFAULT NULL,      -- opsional: cabang / area di Samarinda
  description TEXT,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
--  Jawaban responden (1 baris = 1 kali isi form)
-- ---------------------------------------------------------------------
CREATE TABLE reviews (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  shop_id         INT UNSIGNED NOT NULL,

  -- Halaman 1 form: profil
  reviewer_name   VARCHAR(80)  NOT NULL,      -- Nama
  age_group       VARCHAR(80)  NOT NULL,      -- Usia
  visit_frequency VARCHAR(80)  NOT NULL,      -- Seberapa sering mengunjungi / nongkrong
  avg_spend       VARCHAR(80)  NOT NULL,      -- Rata-rata harga minuman

  -- Halaman 2 form: penilaian skala 1-5
  rating_taste    TINYINT UNSIGNED NOT NULL, -- Rasa Kopi
  rating_facility TINYINT UNSIGNED NOT NULL, -- Fasilitas dan kenyamanan

  -- Halaman 2 form: kebiasaan
  reason          VARCHAR(80)  NOT NULL,      -- Alasan memilih tempat tersebut
  parking         VARCHAR(80)  NOT NULL,      -- Kemudahan & kenyamanan parkir
  visit_time      VARCHAR(80)  NOT NULL,      -- Jam biasa berkunjung
  duration        VARCHAR(80)  NOT NULL,      -- Lama menghabiskan waktu
  non_coffee      VARCHAR(80)  NOT NULL,      -- Variasi menu non-kopi
  purpose         VARCHAR(80)  NOT NULL,      -- Tujuan utama datang
  noise           VARCHAR(80)  NOT NULL,      -- Kebisingan vs fokus nugas

  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_reviews_shop (shop_id),
  CONSTRAINT fk_reviews_shop FOREIGN KEY (shop_id)
    REFERENCES coffee_shops (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
--  Lima coffee shop sesuai pilihan di Google Forms.
--  Kolom "location" dan "description" boleh diisi lewat halaman Admin.
-- ---------------------------------------------------------------------
INSERT INTO coffee_shops (name) VALUES
  ('Kopi Kenangan'),
  ('Tomoro'),
  ('Janji Jiwa'),
  ('Kopi 5'),
  ('Selkop');
